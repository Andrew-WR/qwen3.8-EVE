"""Verify a local signed release, start it, prove EVE readiness, then install.

No production release currently exists. This entrypoint refuses unsigned
development manifests and performs no config mutation before every earlier gate
passes. Registry download/enrollment are provisioning gates, not mocked here.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from urllib.parse import urlsplit

from installer import (
    InstallError,
    apply_config,
    detect_opencode_version,
    find_opencode_binary,
    preflight_config,
    require_supported_version,
    verify_ready,
)


def _run(command: list[str], *, timeout: int = 1200,
         env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(command, capture_output=True, text=True, timeout=timeout,
                            check=False, env=env)
    if result.returncode:
        detail = (result.stderr or result.stdout).strip().splitlines()
        raise InstallError(f"Command failed: {command[0]}: {detail[-1] if detail else result.returncode}")
    return result


def _settings(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for number, raw in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        match = re.fullmatch(r"([A-Z][A-Z0-9_]*)=(.*)", line)
        if not match:
            raise InstallError(f"Unsupported settings syntax at line {number}")
        value = match.group(2).strip()
        if value[:1] in ('"', "'") and value[-1:] == value[:1]:
            value = value[1:-1]
        values[match.group(1)] = value
    return values


def _compose_environment() -> dict[str, str]:
    """Prevent the parent shell from overriding the signed env-file inputs."""
    return {name: value for name, value in os.environ.items()
            if not name.startswith("EVE_") and not name.startswith("COMPOSE_")}


def _validate_rendered_compose(rendered: dict, compose: Path,
                               values: dict[str, str]) -> None:
    smoke = compose.name == "compose.yaml"
    service_name = "eve-tiny-gpu-smoke" if smoke else "eve-gpu"
    image_key = "EVE_SMOKE_IMAGE" if smoke else "EVE_IMAGE"
    services = rendered.get("services")
    if not isinstance(services, dict) or set(services) != {service_name}:
        raise InstallError("Rendered Compose service set does not match the signed profile")
    service = services[service_name]
    if service.get("image") != values.get(image_key):
        raise InstallError("Rendered Compose image differs from the signed settings")
    if service.get("read_only") is not True:
        raise InstallError("Rendered Compose service must use a read-only root filesystem")
    if "ALL" not in service.get("cap_drop", []):
        raise InstallError("Rendered Compose service must drop all Linux capabilities")
    if "no-new-privileges:true" not in service.get("security_opt", []):
        raise InstallError("Rendered Compose service must enable no-new-privileges")
    environment = service.get("environment", {})
    expected_mode = "offline" if compose.name == 'compose.offline.yaml' else ("lease-smoke" if smoke else "lease")
    if (environment.get("EVE_RUNTIME_MODE") != expected_mode
            or environment.get("EVE_PULSE_DIR") != "/run/eve/pulses"):
        raise InstallError("Rendered Compose service has unsafe EVE runtime settings")
    cache_root = "/models/huggingface/eve-runtime-cache/"
    for name in ("TRITON_CACHE_DIR", "TRITON_HOME", "XDG_CACHE_HOME",
                 "TORCHINDUCTOR_CACHE_DIR", "CUDA_CACHE_PATH"):
        if not str(environment.get(name, "")).startswith(cache_root):
            raise InstallError(f"Rendered Compose {name} is outside the writable cache")
    tmpfs = service.get("tmpfs", [])
    if not any(isinstance(value, str) and value.startswith("/run/eve:")
               and "mode=0700" in value and "noexec" in value
               and "nosuid" in value and "nodev" in value for value in tmpfs):
        raise InstallError("Rendered Compose service lacks the private /run/eve tmpfs")
    expected_port = int(values.get("EVE_PORT", "8787"))
    ports = service.get("ports", [])
    if not any(isinstance(port, dict) and port.get("host_ip") == "127.0.0.1"
               and int(port.get("published", 0)) == expected_port
               and int(port.get("target", 0)) == 8000 for port in ports):
        raise InstallError("Rendered Compose API is not bound to the expected loopback port")


def _validate_install_binding(values: dict[str, str], api_key_file: Path,
                              base_url: str) -> None:
    configured_key = Path(values.get("EVE_LOCAL_API_KEY_FILE", ""))
    if api_key_file.resolve() != configured_key.resolve():
        raise InstallError("Readiness and OpenCode must use the Compose local API key")
    parsed = urlsplit(base_url)
    expected_port = int(values.get("EVE_PORT", "8787"))
    if (parsed.scheme != "http" or parsed.hostname != "127.0.0.1"
            or parsed.port != expected_port or parsed.path.rstrip("/") != "/v1"
            or parsed.username is not None or parsed.password is not None
            or parsed.query or parsed.fragment):
        raise InstallError("Readiness URL must select the composed loopback API")


def doctor(opencode_bin: str | None, compose: Path, settings: Path) -> dict:
    binary = find_opencode_binary(opencode_bin)
    version = detect_opencode_version(binary)
    require_supported_version(version)
    docker = _run(["docker", "version", "--format", "{{.Server.Version}}"], timeout=30).stdout.strip()
    compose_version = _run(["docker", "compose", "version", "--short"], timeout=30).stdout.strip()
    gpu = _run(["nvidia-smi", "--query-gpu=name,memory.total,driver_version", "--format=csv,noheader"], timeout=30).stdout.strip()
    values = _settings(settings)
    image_key = "EVE_IMAGE" if compose.name in ("compose.gpu.yaml", "compose.offline.yaml") else "EVE_SMOKE_IMAGE"
    if not re.fullmatch(r".+@sha256:[0-9a-f]{64}", values.get(image_key, "")):
        raise InstallError(f"{image_key} must be an immutable sha256 image reference")
    required_files = ("EVE_CONTROL_KEY_FILE", "EVE_ISSUER_PUBLIC_KEY_FILE",
                      "EVE_LOCAL_API_KEY_FILE", "EVE_LEASE_CLIENT_FILE",
                      "EVE_LEASE_CRYPTO_FILE")
    if compose.name == 'compose.offline.yaml':
        required_files = ('EVE_LOCAL_API_KEY_FILE',)
    for name in required_files:
        candidate = Path(values.get(name, ""))
        if not candidate.is_file() or candidate.is_symlink():
            raise InstallError(f"{name} must select a regular non-link file")
    cache = Path(values.get("EVE_MODEL_CACHE", ""))
    if not cache.is_dir() or cache.is_symlink():
        raise InstallError("EVE_MODEL_CACHE must select a real directory")
    compose_env = _compose_environment()
    rendered_result = _run(
        ["docker", "compose", "--env-file", str(settings), "-f", str(compose),
         "config", "--format", "json"], timeout=30, env=compose_env)
    try:
        rendered = json.loads(rendered_result.stdout)
    except json.JSONDecodeError as exc:
        raise InstallError("Docker Compose did not return valid rendered configuration") from exc
    _validate_rendered_compose(rendered, compose, values)
    return {"ready": True, "opencode": str(version), "docker": docker,
            "compose": compose_version, "gpu": gpu.splitlines()}


def install(args: argparse.Namespace) -> dict:
    verifier = Path(__file__).with_name("release_verify.mjs")
    publisher_digest = hashlib.sha256(args.publisher_key.read_bytes()).hexdigest()
    if not re.fullmatch(r"[0-9a-f]{64}", args.publisher_key_sha256 or ""):
        raise InstallError("Publisher-key SHA-256 pin must be 64 lowercase hex characters")
    if publisher_digest != args.publisher_key_sha256:
        raise InstallError("Publisher public key does not match the out-of-band pin")
    verified = _run(["node", str(verifier), str(args.manifest), str(args.signature),
                     str(args.publisher_key)], timeout=30)
    manifest = json.loads(verified.stdout)
    if manifest["edition"] != args.profile:
        raise InstallError("Signed release edition does not match the selected profile")
    settings = _settings(args.settings)
    _validate_install_binding(settings, args.api_key_file, args.base_url)
    package_root = args.manifest.resolve().parent
    artifacts = manifest["artifacts"]
    expected_paths = {
        "compose": args.compose.resolve(),
        "installer": Path(__file__).with_name("installer.py").resolve(),
        "product_installer": Path(__file__).resolve(),
        "release_verifier": verifier.resolve(),
        "plugin": Path(__file__).with_name("eve-lineage-plugin.mjs").resolve(),
        "lease_client": Path(settings.get("EVE_LEASE_CLIENT_FILE", "")).resolve(),
        "lease_crypto": Path(settings.get("EVE_LEASE_CRYPTO_FILE", "")).resolve(),
    }
    for name, actual in expected_paths.items():
        expected = (package_root / artifacts[name]).resolve()
        if actual != expected:
            raise InstallError(f"{name} path does not select the signed package artifact")
    image_key = "EVE_SMOKE_IMAGE" if args.profile == "tiny-gpu-smoke" else "EVE_IMAGE"
    if settings.get(image_key) != manifest["image"]:
        raise InstallError(f"{image_key} does not match the signed release manifest")
    if args.profile != 'gpu-offline-beta':
        issuer_path = Path(settings.get("EVE_ISSUER_PUBLIC_KEY_FILE", ""))
        issuer_digest = hashlib.sha256(issuer_path.read_bytes()).hexdigest()
        if issuer_digest != manifest["issuer_public_key_sha256"]:
            raise InstallError("Enrolled issuer public key does not match the signed release")
    diagnostics = doctor(args.opencode_bin, args.compose, args.settings)
    binary = find_opencode_binary(args.opencode_bin)
    version = detect_opencode_version(binary)
    preflight = preflight_config(
        args.config, args.profile, version, set_default=args.set_default,
        api_key_file=args.api_key_file,
    )

    # This is the first mutation. Signed issuer enrollment and the complete
    # OpenCode/provider/plugin merge have already passed. apply_config repeats
    # the checks after readiness to guard the preflight-to-apply race.
    _run(["docker", "pull", manifest["image"]])
    inspected = json.loads(_run(["docker", "image", "inspect", "--format",
                                 "{{json .RepoDigests}}", manifest["image"]], timeout=30).stdout)
    if not isinstance(inspected, list) or manifest["image"] not in inspected:
        raise InstallError("Docker did not retain the signed manifest's exact image digest")
    _run(["docker", "compose", "--env-file", str(args.settings), "-f", str(args.compose),
          "up", "-d", "--wait"], env=_compose_environment())

    evidence = verify_ready(args.base_url, args.profile, args.api_key_file)
    applied = apply_config(args.config, args.profile, version, set_default=args.set_default,
                           api_key_file=args.api_key_file)
    return {"installed": True, "release": manifest["version"], "doctor": diagnostics,
            "preflight": preflight, "evidence": evidence, "config": applied}


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description="Verified local EVE product installer")
    sub = result.add_subparsers(dest="command", required=True)
    check = sub.add_parser("doctor")
    check.add_argument("--opencode-bin")
    check.add_argument("--compose", type=Path, required=True)
    check.add_argument("--settings", type=Path, required=True)
    run = sub.add_parser("install")
    run.add_argument("--manifest", type=Path, required=True)
    run.add_argument("--signature", type=Path, required=True)
    run.add_argument("--publisher-key", type=Path, required=True)
    run.add_argument("--publisher-key-sha256", required=True)
    run.add_argument("--settings", type=Path, required=True)
    run.add_argument("--compose", type=Path, required=True)
    run.add_argument("--config", type=Path, required=True)
    run.add_argument("--api-key-file", type=Path, required=True)
    run.add_argument("--opencode-bin")
    run.add_argument("--profile", choices=("tiny-gpu-smoke", "gpu", "gpu-offline-beta"), required=True)
    run.add_argument("--base-url", default="http://127.0.0.1:8787/v1")
    run.add_argument("--set-default", action="store_true")
    return result


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        value = doctor(args.opencode_bin, args.compose, args.settings) if args.command == "doctor" else install(args)
        print(json.dumps(value, indent=2))
        return 0
    except (InstallError, OSError, ValueError, json.JSONDecodeError, subprocess.TimeoutExpired) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
