"""Prepare an explicitly disclosed offline beta install. No account enrollment."""
import argparse
import hashlib
import json
import os
import re
from pathlib import Path
import secrets
import subprocess
import sys


def main():
    p = argparse.ArgumentParser(description='Install EVE offline beta; optional date/version reporting defaults on.')
    p.add_argument('--config', type=Path, required=True, help='Existing OpenCode JSON configuration')
    p.add_argument('--publisher-key-sha256', required=True, help='Fingerprint supplied separately by the publisher')
    p.add_argument('--beta-code', required=True, help='Your EVE-xxxxxxxxxxxxxxxx code from the invitation (not an activation key)')
    p.add_argument('--gpus', type=int, choices=(1, 2, 4, 8), default=1)
    p.add_argument('--model-id', help='Compatible Qwen3.8-27B Hugging Face repository (owner/name)')
    p.add_argument('--model-revision', help='Exact 40-character Hugging Face commit for --model-id')
    p.add_argument('--telemetry-off', action='store_true', help='Disable ALL EVE usage reporting')
    p.add_argument('--report-url', default='', help='Optional publisher Google Apps Script URL')
    p.add_argument('--opencode-bin')
    p.add_argument('--cache', type=Path, default=Path.home() / '.cache/huggingface')
    args = p.parse_args()
    args.beta_code = args.beta_code.strip().upper()
    if re.fullmatch(r'EVE-[0-9A-F]{16}', args.beta_code) is None:
        p.error('Copy the beta code from your invitation: EVE- followed by 16 hexadecimal characters.')
    default_model = 'cyankiwi/Qwen3.8-27B-AWQ-INT4'
    default_revision = '6e134bae811fb5adac50ee042ae5f029ac6779aa'
    if args.model_revision and not args.model_id:
        p.error('--model-revision requires --model-id')
    if args.model_id and not args.model_revision:
        p.error('--model-id requires an exact --model-revision commit')
    model_id = args.model_id or default_model
    model_revision = args.model_revision or default_revision
    if re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*/[A-Za-z0-9][A-Za-z0-9_.-]*', model_id) is None:
        p.error('--model-id must be a Hugging Face owner/repository name')
    if re.fullmatch(r'[0-9a-fA-F]{40}', model_revision) is None:
        p.error('--model-revision must be a 40-character commit hash')
    root = Path(__file__).resolve().parent
    if not args.report_url:
        args.report_url = json.loads((root / 'reporting.json').read_text()).get('url', '')
    print('EVE OFFLINE BETA: full Qwen/multi-GPU parity has not yet been qualified.')
    print('Usage reporting defaults ON: installation ID, beta code, event ID, completion time and version.')
    print('The publisher can use your beta code to match usage to your signup. It is not an activation key.')
    print('No prompts/code/filenames. Disable with --telemetry-off or EVE_TELEMETRY=0 in eve.env.')
    if args.model_id:
        print('CUSTOM CHECKPOINT: architecture is checked before weight download, but EVE quality on this checkpoint is unvalidated.')
    if not args.report_url:
        print('No reporting endpoint configured: no usage data will leave this machine.')
    key = root / 'local-api-key'
    if not key.exists():
        with key.open('x', encoding='utf-8') as f:
            f.write(secrets.token_hex(32))
        key.chmod(0o600)
    args.cache.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((root / 'release.json').read_text())
    # The guarded installer verifies signature, all files and image binding
    # before pulling/starting the worker or changing OpenCode configuration.
    def safe(value):
        value = str(value).replace('\\', '/')
        if any(c in value for c in ('\n', '\r', '"', '$')):
            raise ValueError('unsupported setting characters')
        return '"' + value + '"'
    values = {'EVE_IMAGE': manifest['image'], 'EVE_PORT': '8787',
        'EVE_MODEL_ID': model_id, 'EVE_MODEL_REVISION': model_revision,
        'EVE_TENSOR_PARALLEL_SIZE': str(args.gpus), 'EVE_MODEL_CACHE': args.cache.resolve(),
        'EVE_LOCAL_API_KEY_FILE': key.resolve(), 'EVE_TELEMETRY': '0' if args.telemetry_off else '1',
        'EVE_TELEMETRY_URL': args.report_url,
        'EVE_BETA_CODE': args.beta_code,
        'EVE_LEASE_CLIENT_FILE': root / 'public/lease_client.mjs',
        'EVE_LEASE_CRYPTO_FILE': root / 'public/lease_crypto.mjs'}
    settings = root / 'eve.env'
    if settings.exists():
        if args.model_id:
            p.error('eve.env already exists; model flags would be ignored. Stop EVE and edit EVE_MODEL_ID/EVE_MODEL_REVISION there, or use a fresh install folder.')
        print('Resuming with existing eve.env unchanged. Edit that file to change GPU/reporting settings.')
    else:
        settings.write_text('\n'.join(k + '=' + safe(v) for k, v in values.items()) + '\n', encoding='utf-8')
    command = [sys.executable, str(root / 'product_install.py'), 'install',
        '--manifest', str(root / 'release.json'), '--signature', str(root / 'release.json.sig'),
        '--publisher-key', str(root / 'publisher-public.pem'),
        '--publisher-key-sha256', args.publisher_key_sha256,
        '--settings', str(settings), '--compose', str(root / 'compose.offline.yaml'),
        '--config', str(args.config.resolve()), '--api-key-file', str(key),
        '--profile', 'gpu-offline-beta']
    if args.opencode_bin:
        command.extend(['--opencode-bin', args.opencode_bin])
    return subprocess.call(command)


if __name__ == '__main__':
    raise SystemExit(main())
