"""Plan, install, health-check, and roll back the local OpenCode integration.

The default ``plan`` command is read-only. ``apply`` is deliberately explicit,
backs up an existing configuration, and writes atomically.  This module has no
third-party dependencies so the bootstrap path works before Docker is running.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
import re
import secrets
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping


PROVIDER_ID = "local-eve"
SCHEMA_URL = "https://opencode.ai/config.json"
DEFAULT_BASE_URL = "http://127.0.0.1:8787/v1"
PROFILE_MODELS = {
    "gpu": {
        "id": "qwen-27b-eve",
        "name": "Qwen 27B EVE (local customer GPU)",
        "context": None,
        "test_only": False,
        "layer": 32,
        "runtime": "vllm-0.17.0-eve-0.1",
    },
    "tiny-gpu-smoke": {
        "id": "qwen2.5-0.5b-eve-smoke",
        "name": "Qwen2.5 0.5B EVE GPU engineering smoke (test only)",
        "context": 8192,
        "output": 512,
        "test_only": True,
        "layer": None,
        "runtime": "vllm-0.17.0-eve-smoke",
    },
}
PLUGIN_FILENAME = "eve-lineage-plugin.mjs"
PROFILE_MODELS['gpu-offline-beta'] = {**PROFILE_MODELS['gpu'],
    'name': 'Qwen 27B EVE offline beta (GPU parity not yet qualified)'}
PLUGIN_SOURCE = Path(__file__).with_name(PLUGIN_FILENAME)
SUPPORTED_MIN = (1, 18, 0)
SUPPORTED_MAX_EXCLUSIVE = (1, 19, 0)


class InstallError(RuntimeError):
    """Base class for an installer refusal."""


class UnsupportedConfig(InstallError):
    """The configuration cannot be safely rewritten."""


class ConfigConflict(InstallError):
    """The customer already owns a conflicting EVE provider entry."""


@dataclass(frozen=True, order=True)
class OpenCodeVersion:
    major: int
    minor: int
    patch: int
    source: str = "command"

    def __str__(self) -> str:
        return f"{self.major}.{self.minor}.{self.patch}"

    @property
    def tuple(self) -> tuple[int, int, int]:
        return (self.major, self.minor, self.patch)


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _parse_version(text: str, source: str) -> OpenCodeVersion | None:
    match = re.search(r"(?<![\d.])(\d+)\.(\d+)\.(\d+)(?![\d.])", text)
    if not match:
        return None
    return OpenCodeVersion(*(int(part) for part in match.groups()), source=source)


def find_opencode_binary(explicit: str | os.PathLike[str] | None = None) -> Path:
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit))
    if os.environ.get("OPENCODE_BIN"):
        candidates.append(Path(os.environ["OPENCODE_BIN"]))
    found = shutil.which("opencode")
    if found:
        candidates.append(Path(found))
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    raise InstallError("OpenCode was not found; pass --opencode-bin or set OPENCODE_BIN")


def detect_opencode_version(binary: str | os.PathLike[str]) -> OpenCodeVersion:
    """Detect the installed version, falling back to a versioned bundle path.

    Some packaged Windows binaries can fail before handling ``--version`` when
    their global config directory is unhealthy. A directory such as
    ``opencode-1.18.34`` is therefore an accepted, explicitly reported fallback.
    """

    binary_path = Path(binary).resolve()
    try:
        result = subprocess.run(
            [str(binary_path), "--version"],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        result = None
        command_error = str(exc)
    else:
        command_error = (result.stderr or result.stdout).strip()
        if result.returncode == 0:
            version = _parse_version(result.stdout.strip(), "command")
            if version:
                return version

    for part in reversed(binary_path.parts):
        match = re.fullmatch(r"opencode[-_](\d+\.\d+\.\d+)", part, re.IGNORECASE)
        if match:
            version = _parse_version(match.group(1), "versioned-path")
            if version:
                return version
    raise InstallError(f"Could not determine OpenCode version: {command_error or 'no version output'}")


def require_supported_version(version: OpenCodeVersion) -> None:
    if not (SUPPORTED_MIN <= version.tuple < SUPPORTED_MAX_EXCLUSIVE):
        raise InstallError(
            f"OpenCode {version} is unsupported; this installer is validated for 1.18.x only"
        )


def load_strict_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    raw = path.read_text(encoding="utf-8-sig")
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise UnsupportedConfig(
            f"{path} is not strict JSON (comments/JSONC are left untouched): {exc.msg}"
        ) from exc
    if not isinstance(value, dict):
        raise UnsupportedConfig(f"{path} must contain a JSON object")
    return value


def build_provider(profile: str) -> dict[str, Any]:
    try:
        model = PROFILE_MODELS[profile]
    except KeyError as exc:
        raise InstallError(f"Unknown profile: {profile}") from exc
    return {
        "npm": "@ai-sdk/openai-compatible",
        "name": "Local EVE",
        "options": {
            "baseURL": "{env:LOCAL_EVE_BASE_URL}",
            "apiKey": "eve-local-plugin-managed",
        },
        "models": {
            model["id"]: {
                "name": model["name"],
                "toolcall": True,
                **({"limit": {"context": model["context"], "output": model["output"]}}
                   if model["test_only"] else {}),
            }
        },
    }


def merge_config(
    existing: Mapping[str, Any],
    profile: str,
    *,
    set_default: bool = False,
    plugin_uri: str | None = None,
    api_key_file: Path | None = None,
) -> tuple[dict[str, Any], bool]:
    """Return a non-mutating semantic merge and whether it changes the input."""

    if not isinstance(existing, Mapping):
        raise UnsupportedConfig("OpenCode configuration root must be an object")
    result = json.loads(json.dumps(existing))
    providers = result.setdefault("provider", {})
    if not isinstance(providers, dict):
        raise UnsupportedConfig("OpenCode 'provider' must be an object")
    wanted = build_provider(profile)
    current = providers.get(PROVIDER_ID)
    if current is not None and current != wanted:
        raise ConfigConflict(
            f"provider.{PROVIDER_ID} already exists with different settings; refusing to overwrite it"
        )
    providers[PROVIDER_ID] = wanted
    if plugin_uri:
        plugins = result.setdefault("plugin", [])
        if not isinstance(plugins, list) or not all(
            isinstance(item, (str, list)) for item in plugins
        ):
            raise UnsupportedConfig("OpenCode 'plugin' must be an array")
        plugin_entry: Any = plugin_uri
        if api_key_file is not None:
            plugin_entry = [plugin_uri, {"apiKeyFile": str(api_key_file.resolve())}]
        if plugin_entry not in plugins:
            plugins.append(plugin_entry)
    result.setdefault("$schema", SCHEMA_URL)
    result.setdefault("share", "disabled")
    if set_default:
        model_id = PROFILE_MODELS[profile]["id"]
        desired_default = f"{PROVIDER_ID}/{model_id}"
        current_default = result.get("model")
        if current_default not in (None, desired_default):
            raise ConfigConflict(
                f"model is already {current_default!r}; use the explicit --model selector instead"
            )
        result["model"] = desired_default
    return result, result != dict(existing)


def _canonical_bytes(value: Mapping[str, Any]) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise InstallError(f"Refusing to replace symbolic link: {path}")
    handle, temporary = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(handle, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass


def apply_config(
    config_path: Path,
    profile: str,
    version: OpenCodeVersion,
    *,
    set_default: bool = False,
    plugin_target: Path | None = None,
    api_key_file: Path | None = None,
) -> dict[str, Any]:
    require_supported_version(version)
    if config_path.is_symlink():
        raise InstallError(f"Refusing to modify symbolic link: {config_path}")
    existed = config_path.exists()
    before = config_path.read_bytes() if existed else b""
    if plugin_target is None:
        plugin_target = config_path.parent / ".eve" / PLUGIN_FILENAME
    plugin_target = plugin_target.resolve()
    plugin_data = PLUGIN_SOURCE.read_bytes()
    plugin_created = False
    if plugin_target.exists():
        if plugin_target.is_symlink() or plugin_target.read_bytes() != plugin_data:
            raise ConfigConflict(f"Plugin target already exists with different content: {plugin_target}")
    else:
        plugin_created = True
    existing = load_strict_json(config_path)
    merged, changed = merge_config(
        existing, profile, set_default=set_default, plugin_uri=plugin_target.as_uri(),
        api_key_file=api_key_file,
    )
    if not changed and not plugin_created:
        return {"changed": False, "config": str(config_path), "version": str(version)}

    backup_dir = config_path.parent / ".eve-backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    before_digest = _sha256(before)
    backup_path = backup_dir / f"{config_path.name}.{stamp}.{before_digest[:12]}.bak"
    counter = 0
    while backup_path.exists():
        counter += 1
        backup_path = backup_dir / f"{config_path.name}.{stamp}.{before_digest[:12]}.{counter}.bak"
    with backup_path.open("xb") as stream:
        stream.write(before)
    if os.name != "nt":
        backup_path.chmod(0o600)

    installed = _canonical_bytes(merged)
    if plugin_created:
        _atomic_write(plugin_target, plugin_data)
    try:
        _atomic_write(config_path, installed)
    except Exception:
        if plugin_created and plugin_target.exists() and plugin_target.read_bytes() == plugin_data:
            plugin_target.unlink()
        raise
    state = {
        "format": 1,
        "config": str(config_path.resolve()),
        "backup": str(backup_path.resolve()),
        "config_existed": existed,
        "before_sha256": before_digest,
        "installed_sha256": _sha256(installed),
        "opencode_version": str(version),
        "profile": profile,
        "plugin": str(plugin_target),
        "plugin_sha256": _sha256(plugin_data),
        "plugin_created": plugin_created,
    }
    state_path = backup_dir / "latest-install.json"
    _atomic_write(state_path, _canonical_bytes(state))
    return {"changed": True, "state": str(state_path), **state}


def preflight_config(
    config_path: Path,
    profile: str,
    version: OpenCodeVersion,
    *,
    set_default: bool = False,
    plugin_target: Path | None = None,
    api_key_file: Path | None = None,
) -> dict[str, Any]:
    """Prove the later apply is compatible without changing any filesystem state.

    ``apply_config`` intentionally repeats every check to close the race between
    preflight and the eventual post-readiness mutation.
    """
    require_supported_version(version)
    if config_path.is_symlink():
        raise InstallError(f"Refusing to modify symbolic link: {config_path}")
    if plugin_target is None:
        plugin_target = config_path.parent / ".eve" / PLUGIN_FILENAME
    plugin_target = plugin_target.resolve()
    plugin_data = PLUGIN_SOURCE.read_bytes()
    if plugin_target.exists() and (
        plugin_target.is_symlink() or plugin_target.read_bytes() != plugin_data
    ):
        raise ConfigConflict(
            f"Plugin target already exists with different content: {plugin_target}"
        )
    existing = load_strict_json(config_path)
    merged, changed = merge_config(
        existing, profile, set_default=set_default,
        plugin_uri=plugin_target.as_uri(), api_key_file=api_key_file,
    )
    return {
        "compatible": True,
        "would_change": changed or not plugin_target.exists(),
        "config": str(config_path.resolve()),
        "plugin": str(plugin_target),
        "merged_sha256": _sha256(_canonical_bytes(merged)),
    }


def rollback(state_path: Path) -> dict[str, Any]:
    state = load_strict_json(state_path)
    if state.get("format") != 1:
        raise InstallError("Unknown rollback-state format")
    config_path = Path(str(state.get("config", ""))).resolve()
    backup_path = Path(str(state.get("backup", ""))).resolve()
    expected_state_dir = (config_path.parent / ".eve-backups").resolve()
    if state_path.resolve().parent != expected_state_dir:
        raise InstallError("Rollback state is outside the config backup directory")
    if state_path.resolve().parent != backup_path.parent:
        raise InstallError("Rollback backup is outside the recorded state directory")
    if config_path.is_symlink() or backup_path.is_symlink():
        raise InstallError("Refusing rollback through a symbolic link")
    current = config_path.read_bytes() if config_path.exists() else b""
    if _sha256(current) != state.get("installed_sha256"):
        raise ConfigConflict("OpenCode config changed after EVE installation; rollback refused")
    backup = backup_path.read_bytes()
    if _sha256(backup) != state.get("before_sha256"):
        raise InstallError("Rollback backup digest does not match its manifest")
    plugin_path: Path | None = None
    plugin_value = state.get("plugin")
    if state.get("plugin_created") and plugin_value:
        plugin_path = Path(str(plugin_value)).resolve()
        if plugin_path.is_symlink():
            raise InstallError("Refusing to remove a symbolic-link plugin")
        if not plugin_path.exists() or _sha256(plugin_path.read_bytes()) != state.get("plugin_sha256"):
            raise ConfigConflict("EVE lineage plugin changed after installation; rollback refused")
    if state.get("config_existed"):
        _atomic_write(config_path, backup)
        action = "restored"
    else:
        config_path.unlink(missing_ok=False)
        action = "removed-created-config"
    plugin_action = "preserved-preexisting"
    if plugin_path:
        plugin_path.unlink()
        plugin_action = "removed-installed-plugin"
    return {"rolled_back": True, "action": action, "plugin_action": plugin_action,
            "config": str(config_path)}


def verify_ready(
    base_url: str,
    profile: str,
    api_key_file: Path | None = None,
    *,
    timeout: float = 120.0,
) -> dict[str, Any]:
    """Run the real EVE ingress gate twice; ordinary vLLM cannot pass it.

    A primary and auxiliary completion are launched concurrently to force a
    mixed batch. Request IDs prove request-scoped routing only; the subsequent
    authenticated evidence endpoint must separately attest the audited actuator
    self-test, isolation check, and schedule commit check.
    """
    model = PROFILE_MODELS[profile]
    root = base_url.removesuffix("/v1").rstrip("/")
    if api_key_file is None:
        raise InstallError("The fail-closed gate requires --api-key-file")
    info = api_key_file.lstat()
    if api_key_file.is_symlink() or not stat.S_ISREG(info.st_mode) or info.st_size > 4096:
        raise InstallError("Local API key path must be a small regular file, not a link")
    if os.name != "nt" and info.st_mode & (stat.S_IRWXG | stat.S_IRWXO):
        raise InstallError("Local API key file must not grant group/other permissions")
    key = api_key_file.read_text(encoding="utf-8").strip()
    if len(key) < 24:
        raise InstallError("Local API key must contain at least 24 characters")
    try:
        with urllib.request.urlopen(f"{root}/health", timeout=min(timeout, 10.0)) as response:
            if response.status != 200:
                raise InstallError(f"Runtime health endpoint returned HTTP {response.status}")
    except (OSError, urllib.error.URLError, json.JSONDecodeError) as exc:
        raise InstallError(f"EVE runtime health check failed: {exc}") from exc

    endpoint = f"{root}/v1/chat/completions"
    # Keep the auxiliary in a real prefill/decode forward while the primary
    # performs encrypted lease admission. This avoids mistaking HTTP overlap
    # for a mixed model forward on fast tiny models.
    auxiliary_prompt = "Continue briefly after reading: " + ("hold " * 2048)

    def probe(agent: str, session: str) -> str:
        prompt = "Reply with OK." if agent == "primary" else auxiliary_prompt
        body = json.dumps({
            "model": model["id"],
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 2,
            "temperature": 0,
            "stream": False,
        }).encode("utf-8")
        request = urllib.request.Request(endpoint, data=body, method="POST", headers={
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
            "X-EVE-Session": session,
            "X-EVE-Agent": agent,
            "X-EVE-Source-Digest": hashlib.sha256(b'').hexdigest(),
            "X-EVE-Source-Dirty": "0",
        })
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                value = json.load(response)
                request_id = response.headers.get("X-Request-Id", "")
        except (OSError, urllib.error.URLError, json.JSONDecodeError) as exc:
            raise InstallError(f"EVE completion gate failed: {exc}") from exc
        choices = value.get("choices") if isinstance(value, dict) else None
        content = choices[0].get("message", {}).get("content") if choices else None
        if not isinstance(content, str):
            raise InstallError("EVE completion gate returned no assistant content")
        suffix = "p" if agent == "primary" else "a"
        expected = rf"^eve1-{session}-[0-9a-f]{{32}}-{suffix}$"
        if not re.fullmatch(expected, request_id):
            raise InstallError("Runtime did not return verified EVE generation evidence")
        return request_id

    expected_layer = 1 if profile == "tiny-gpu-smoke" else model["layer"]
    expected = {
        "eve_enabled": True,
        "model": model["id"],
        "runtime": model["runtime"],
        "activation_site": "layer_input",
        "layer": expected_layer,
        "self_test": "passed",
        "request_isolation": "passed",
        "mixed_batch_evidence": True,
        "numerical_fixture_selftest": "passed",
        "real_model_site_observed": True,
        "actual_activation_change": True,
        **({"offline_artifact_verified": True, "delivery_mode": "offline"}
           if profile == 'gpu-offline-beta' else {"lease_verified": True}),
        "commit_status": "healthy",
        "qwen_parity": "unvalidated" if profile in ("tiny-gpu-smoke", "gpu-offline-beta") else "validated",
    }
    expected_context = model["context"]
    last_evidence: Any = None
    for _attempt in range(3):
        session = secrets.token_hex(32)
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            futures = [executor.submit(probe, agent, session)
                       for agent in ("primary", "auxiliary")]
            request_ids = [future.result() for future in futures]
        if request_ids[0] == request_ids[1]:
            raise InstallError("EVE runtime reused a generation ID across two API calls")

        ready_request = urllib.request.Request(f"{root}/internal/eve/ready", headers={
            "Authorization": f"Bearer {key}",
        })
        try:
            with urllib.request.urlopen(ready_request,
                                        timeout=min(timeout, 10.0)) as response:
                evidence = json.load(response)
        except urllib.error.HTTPError as exc:
            if exc.code != 503:
                raise InstallError(
                    f"EVE mixed-batch readiness evidence failed: HTTP {exc.code}"
                ) from exc
            try:
                evidence = json.load(exc)
            except (OSError, json.JSONDecodeError) as parse_exc:
                raise InstallError("EVE readiness returned an invalid pending response") from parse_exc
        except (OSError, urllib.error.URLError, json.JSONDecodeError) as exc:
            raise InstallError(f"EVE mixed-batch readiness evidence failed: {exc}") from exc
        last_evidence = evidence
        matches = (isinstance(evidence, dict)
                   and not any(evidence.get(k) != v for k, v in expected.items())
                   and (evidence.get("context_tokens") == expected_context
                        if expected_context is not None else
                        isinstance(evidence.get("context_tokens"), int)
                        and evidence["context_tokens"] > 0)
                   and evidence.get("observed_primary", 0) >= 1
                   and evidence.get("observed_auxiliary", 0) >= 1)
        if matches:
            return {
                **evidence,
                "profile": profile,
                "session": session,
                "generation_request_ids": request_ids,
                "mixed_batch_gate": "passed",
                "test_only": model["test_only"],
            }
    raise InstallError(
        "EVE readiness did not observe a nonzero mixed primary/auxiliary model forward "
        "after three fresh sessions"
    )


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Safe local EVE/OpenCode installer")
    parser.add_argument("--opencode-bin", help="path to the OpenCode executable")
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("plan", "apply"):
        command = sub.add_parser(name)
        command.add_argument("--config", type=Path, required=True)
        command.add_argument("--profile", choices=PROFILE_MODELS, default="gpu")
        command.add_argument("--set-default", action="store_true")
        command.add_argument("--base-url", default=DEFAULT_BASE_URL)
        command.add_argument("--api-key-file", type=Path, required=name == "apply")
        command.add_argument("--plugin-target", type=Path)
    undo = sub.add_parser("rollback")
    undo.add_argument("--state", type=Path, required=True)
    ready = sub.add_parser("healthcheck")
    ready.add_argument("--profile", choices=PROFILE_MODELS, default="gpu")
    ready.add_argument("--base-url", default=DEFAULT_BASE_URL)
    ready.add_argument("--api-key-file", type=Path)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.command == "rollback":
            result = rollback(args.state)
        elif args.command == "healthcheck":
            result = verify_ready(args.base_url, args.profile, args.api_key_file)
        else:
            binary = find_opencode_binary(args.opencode_bin)
            version = detect_opencode_version(binary)
            require_supported_version(version)
            existing = load_strict_json(args.config)
            plugin_target = (args.plugin_target or args.config.parent / ".eve" / PLUGIN_FILENAME).resolve()
            merged, changed = merge_config(
                existing, args.profile, set_default=args.set_default,
                plugin_uri=plugin_target.as_uri(),
                api_key_file=args.api_key_file,
            )
            if args.command == "plan":
                result = {
                    "action": "plan-only",
                    "changed": changed,
                    "config": str(args.config),
                    "opencode": str(binary),
                    "opencode_version": str(version),
                    "version_source": version.source,
                    "profile": args.profile,
                    "model": f"{PROVIDER_ID}/{PROFILE_MODELS[args.profile]['id']}",
                    "lineage_plugin": str(plugin_target),
                    "environment": {
                        "LOCAL_EVE_BASE_URL": args.base_url,
                        "LOCAL_EVE_API_KEY": "not required; plugin reads the protected key file",
                    },
                    "preview": merged,
                }
            else:
                verify_ready(args.base_url, args.profile, args.api_key_file)
                result = apply_config(
                    args.config, args.profile, version, set_default=args.set_default,
                    plugin_target=plugin_target, api_key_file=args.api_key_file,
                )
        print(json.dumps(result, indent=2))
        return 0
    except (InstallError, OSError, ValueError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
