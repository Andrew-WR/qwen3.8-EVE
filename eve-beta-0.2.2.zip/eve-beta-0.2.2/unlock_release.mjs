// Unlock the signed release manifest using the code shown after beta signup.
// The manifest is still authenticated by the publisher's Ed25519 signature.
import {createDecipheriv, verify} from 'node:crypto';
import {readFile, writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const [code, imageRepository] = process.argv.slice(2);
if (!/^[A-Za-z0-9_-]{43}$/.test(code ?? '') ||
    !/^[a-z0-9]+(?:[._/-][a-z0-9]+)*$/.test(imageRepository ?? '')) {
  throw new Error('usage: node unlock_release.mjs UNLOCK_CODE IMAGE_REPOSITORY');
}
const key = Buffer.from(code, 'base64url');
if (key.length !== 32 || key.toString('base64url') !== code) throw new Error('invalid unlock code');
const payload = await readFile(path.join(root, 'release.json.enc'));
if (payload.length < 33 || payload.subarray(0, 4).toString() !== 'EVE1') {
  throw new Error('invalid encrypted release format');
}
const nonce = payload.subarray(4, 16);
const tag = payload.subarray(16, 32);
const decipher = createDecipheriv('aes-256-gcm', key, nonce);
decipher.setAuthTag(tag);
let manifestBytes;
try {
  manifestBytes = Buffer.concat([decipher.update(payload.subarray(32)), decipher.final()]);
} catch {
  throw new Error('incorrect unlock code or damaged release file');
}
const manifest = JSON.parse(manifestBytes);
if (manifest.status !== 'signed-release' ||
    manifest.image !== `${imageRepository}@sha256:${manifest.image_digest}`) {
  throw new Error('image repository does not match the signed release');
}
const signatureText = (await readFile(path.join(root, 'release.json.sig'), 'utf8')).trim();
const signature = Buffer.from(signatureText, 'base64');
const publicKey = await readFile(path.join(root, 'publisher-public.pem'));
if (!verify(null, manifestBytes, publicKey, signature)) {
  throw new Error('publisher signature verification failed');
}
try {
  await writeFile(path.join(root, 'release.json'), manifestBytes, {flag: 'wx', mode: 0o600});
} catch (error) {
  if (error.code !== 'EEXIST') throw error;
  const previous = await readFile(path.join(root, 'release.json'));
  if (!previous.equals(manifestBytes)) throw new Error('existing release.json differs from this release');
}
console.log('Signed release unlocked. Continue with beta_setup.py.');
