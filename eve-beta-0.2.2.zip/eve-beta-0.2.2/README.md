# EVE offline beta

This experimental build has passed a real laptop tiny-model/OpenCode integration
check. Full Qwen 27B and multi-GPU numerical/quality parity require separate GPU
qualification; beta availability is not a claim those checks have passed.

## Requirements

NVIDIA GPU(s) with enough memory for the model/KV cache, Docker with GPU support,
Python 3.10+, Node 22+, OpenCode 1.18.x (tested 1.18.34), and a Git project with
an existing commit. Keep an existing OpenCode JSON config; JSONC is not supported
by this guarded beta installer. Image/model downloads require internet once.
After downloads EVE needs no authority, account activation, license renewal,
Google connection or remote credentials. OpenCode itself may use other online
services/plugins; EVE cannot promise all unrelated OpenCode features are offline.

## Install

Obtain the publisher-key SHA-256 fingerprint in the invitation separately from
the bundle. Never accept an unexpected fingerprint from the downloaded files.
The customer images are public. No Docker Hub invitation or login is required
(Docker Hub download rate limits can still apply). Copy the beta code from your
invitation. This code is for optional signup attribution, not online activation.

From the extracted bundle:

```sh
python beta_setup.py --config /path/to/opencode.json --gpus 2 --beta-code YOUR_BETA_CODE --publisher-key-sha256 FINGERPRINT_FROM_INVITATION
opencode --model local-eve/qwen-27b-eve
```

Use `--gpus 1` for one GPU. Do not expect a 27B model and native-length KV cache
to fit on every GPU; the installer reports errors rather than silently disabling
EVE. There are no EVE-added response, context, call-count or generation-duration
caps. Normal model/hardware/OpenCode limits still apply.

This signed release can also select a compatible Hugging Face checkpoint:

```sh
python beta_setup.py --config /path/to/opencode.json --gpus 4 \
  --beta-code YOUR_BETA_CODE --publisher-key-sha256 FINGERPRINT_FROM_INVITATION \
  --model-id Qwen/Qwen3.8-27B --model-revision EXACT_40_CHARACTER_COMMIT
```

The model revision must be an exact commit, not `main`, so installs are
reproducible. The worker checks Qwen3.8-27B architecture, width, layer count,
and vocabulary before downloading weights. vLLM chooses the quantization mode
from the checkpoint's config. This is compatibility support, not a promise that
every third-party quantization loads or that the EVE vectors produce the same
quality as the calibrated checkpoint. Full-precision weights require much more
GPU memory than the default 4-bit model. Existing installed folders keep their
`eve.env`; stop EVE and edit `EVE_MODEL_ID`/`EVE_MODEL_REVISION` in that file
before restarting if changing models later.

The installer preserves existing providers/defaults/permissions, verifies the
release and pinned image, starts the local worker, checks actual activation and
request isolation, then installs the OpenCode plugin. A local API key protects
the loopback-only server; it is not an online license. The installed state file
supports `python installer.py rollback --state PATH` to restore configuration.
Stop only this product with `docker compose --env-file eve.env -f compose.offline.yaml stop`.

## Optional reporting (default ON)

If the publisher configured a reporting URL, successful primary requests send
only a random installation ID, random event ID, beta code, usage date/time and version to
Google. No prompts, code, responses, filenames, email or conversation IDs are
sent. The publisher can match your beta code to your signup using its private
records; these are pseudonymous, not anonymous reports. Google receives ordinary network metadata. Offline/network/reporting
failures never interrupt EVE. Local queued reports may be retried for 30 days
(maximum 2,000 entries); counts are approximate.

Disable on installation with `--telemetry-off`. To change later, set
`EVE_TELEMETRY=0` in `eve.env` and run:

```sh
docker compose --env-file eve.env -f compose.offline.yaml up -d
```

No configured reporting URL means no usage data is sent, even with the toggle on.
Keep model weights cached for offline restarts. Keep the `eve-state` Docker volume
to preserve conversation schedule positions. No private signing key ships in
this bundle. Compiled/encrypted local payloads discourage casual inspection but
can be extracted by an administrator.
