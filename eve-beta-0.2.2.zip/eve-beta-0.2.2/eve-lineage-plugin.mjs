import { createHash } from "node:crypto";
import { lstatSync, readFileSync, realpathSync } from "node:fs";
import { execFileSync } from "node:child_process";
import path from "node:path";

const PROVIDER = "local-eve";
const AUXILIARY_AGENTS = new Set(["title", "summary", "compaction"]);

// Only two opaque values leave the machine. No path, diff, code, or tool text
// is sent to the authority. Git inspection is read-only, without a shell.
export function sourceState(directory) {
  const root = realpathSync(directory);
  const git = args => execFileSync('git', ['-C', root, ...args], {
    maxBuffer: 32 * 1024 * 1024, timeout: 10000, windowsHide: true,
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  git(['rev-parse', '--verify', 'HEAD']);
  const sourcePath = name => !/(^|\/)(tests?|__tests__)(\/|$)/i.test(name)
    && !/(^|\/)(test_[^/]*|repro[^/]*|patch[.]txt|[^/]*_test[.]py|[^/]*[._]test[.][^/]*)$/i.test(name);
  const diff = git(['diff', '--binary', '--no-ext-diff', '--no-textconv', 'HEAD', '--', '.',
    ':(exclude,glob)**/tests/**', ':(exclude,glob)**/test/**',
    ':(exclude,glob)**/test_*', ':(exclude,glob)**/*.test.*',
    ':(exclude,glob)**/__tests__/**', ':(exclude,glob)**/repro*',
    ':(exclude,glob)**/patch.txt', ':(exclude,glob)**/*_test.py']);
  const hash = createHash('sha256').update(diff);
  let dirty = diff.length > 0, bytes = diff.length;
  const names = git(['ls-files', '--others', '--exclude-standard', '-z']).toString('utf8').split('\0').filter(Boolean).sort();
  for (const name of names.filter(sourcePath)) {
    const target = path.resolve(root, name);
    const relative = path.relative(root, realpathSync(target));
    if (relative.startsWith('..') || path.isAbsolute(relative) || lstatSync(target).isSymbolicLink())
      throw Error('EVE source inspection refuses external or symbolic-link files');
    const info = lstatSync(target);
    if (!info.isFile() || (bytes += info.size) > 32 * 1024 * 1024)
      throw Error('EVE source snapshot exceeds the inspection bound');
    hash.update('\0').update(name).update('\0').update(readFileSync(target)); dirty = true;
  }
  return { sourceDigest: hash.digest('hex'), sourceDirty: dirty };
}

export function lineageHeaders(input, namespace = process.env.EVE_LINEAGE_NAMESPACE ?? "eve-local-v1") {
  const providerID = input?.provider?.info?.id ?? input?.model?.providerID;
  if (providerID !== PROVIDER) return {};
  if (typeof input.sessionID !== "string" || input.sessionID.length === 0) {
    throw new Error("EVE lineage requires a nonempty OpenCode sessionID");
  }
  const session = createHash("sha256")
    .update(String(namespace), "utf8")
    .update("\0", "utf8")
    .update(input.sessionID, "utf8")
    .digest("hex");
  const agentName = String(input.agent ?? "").toLowerCase();
  const auxiliary = AUXILIARY_AGENTS.has(agentName);
  return {
    "X-EVE-Session": session,
    "X-EVE-Agent": auxiliary ? "auxiliary" : "primary",
    ...(auxiliary ? { "X-EVE-Aux-Kind": agentName } : {}),
  };
}

export const EveLineagePlugin = async (context, options = {}) => {
  let authorization;
  if (options.apiKeyFile !== undefined) {
    if (typeof options.apiKeyFile !== "string" || !options.apiKeyFile) throw new Error("invalid EVE apiKeyFile option");
    const info = lstatSync(options.apiKeyFile);
    if (!info.isFile() || info.isSymbolicLink() || info.size > 4096) throw new Error("invalid EVE API key file");
    const key = readFileSync(options.apiKeyFile, "utf8").trim();
    if (key.length < 24) throw new Error("invalid EVE API key file");
    authorization = `Bearer ${key}`;
  }
  return {
    // Advertise the server's real model capacity for OpenCode compaction,
    // without inventing a context/output ceiling or changing native budgets.
    "config": async config => {
      const provider = config.provider?.[PROVIDER];
      const model = provider?.models?.['qwen-27b-eve'];
      if (!model || model.limit?.context !== undefined) return;
      let base = provider.options?.baseURL;
      const variable = typeof base === 'string' && /^\{env:([A-Z_][A-Z0-9_]*)\}$/.exec(base);
      if (variable) base = process.env[variable[1]];
      const url = new URL(String(base).replace(/\/$/, '') + '/models');
      if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password)
        throw Error('invalid EVE model metadata URL');
      const response = await fetch(url, {headers: authorization ? {Authorization: authorization} : {},
        signal: AbortSignal.timeout(10000), redirect: 'error'});
      if (!response.ok) throw Error('EVE model metadata is unavailable');
      const card = (await response.json()).data?.find(item => item.id === 'qwen-27b-eve');
      if (!Number.isSafeInteger(card?.max_model_len) || card.max_model_len < 1)
        throw Error('EVE runtime did not report its native context capacity');
      model.limit = {...model.limit, context: card.max_model_len};
    },
    "chat.headers": async (input, output) => {
      const headers = lineageHeaders(input, options.namespace);
      if (headers['X-EVE-Agent'] === 'primary' && context?.directory) {
        const state = sourceState(context.directory);
        headers['X-EVE-Source-Digest'] = state.sourceDigest;
        headers['X-EVE-Source-Dirty'] = state.sourceDirty ? '1' : '0';
      }
      if (authorization && Object.keys(headers).length) headers.Authorization = authorization;
      Object.assign(output.headers, headers);
    },
  };
};

export default EveLineagePlugin;
