# EVE beta starter

This ZIP contains the installer and an encrypted, signed release manifest.
First complete https://forms.gle/rYQZiPSYtmZEuEQ69. The form's completion page
shows your unique beta code, the image repository, and a release unlock code.
Copy all three before leaving that page. No additional ZIP or email is needed.

You need NVIDIA GPUs with enough memory for Qwen 27B, Docker with NVIDIA GPU
support, Python 3.10+, Node 22+, OpenCode 1.18.x, an existing OpenCode JSON
configuration, and a Git project with at least one commit. Full Qwen 27B and
multi-GPU qualification is still experimental.

Open a terminal in this extracted folder and run, replacing the unlock code,
image repository, configuration path, GPU count, and beta code with the values
from the form completion page:

```sh
node unlock_release.mjs YOUR_UNLOCK_CODE IMAGE_REPOSITORY
python beta_setup.py --config /path/to/opencode.json --gpus 2 --beta-code YOUR_BETA_CODE --publisher-key-sha256 bb479b776acd32a8644b41626feb19b08b81aad3abb93b6092a88338e2250f00
opencode --model local-eve/qwen-27b-eve
```

To use another compatible Hugging Face checkpoint, add its repository and exact
commit to the `beta_setup.py` command. For example, the official unquantized
model at this pinned revision requires substantially more GPU memory:

```sh
python beta_setup.py --config /path/to/opencode.json --gpus 4 --beta-code YOUR_BETA_CODE --publisher-key-sha256 bb479b776acd32a8644b41626feb19b08b81aad3abb93b6092a88338e2250f00 --model-id Qwen/Qwen3.8-27B --model-revision 1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0
```

Replace both model arguments for a different checkpoint. The signed installer
pins the EVE Docker image separately from your chosen model revision.

Use `--gpus 1` for one GPU. The unlock command decrypts the release manifest,
checks its publisher signature and verifies that the image repository matches
what you entered. The installer then checks every signed file and the pinned
image digest before pulling the image or changing OpenCode configuration.
The release unlock code is shared for this release; your beta code is unique.

Once downloaded, EVE runs offline. Optional date/version usage reporting is on
by default and includes your beta code and a random installation ID. It can be
disabled with `--telemetry-off`; reporting failures never stop EVE. It does not
send prompts, responses, code, filenames, or email addresses. See `README.md`
for the full requirements, privacy details, and rollback instructions.
