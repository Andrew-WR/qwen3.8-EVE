import { readFileSync, lstatSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { newChallenge, unseal } from './lease_crypto.mjs';

export function readControlKey(env = process.env) {
  if (env.EVE_CONTROL_KEY_FILE) {
    if (env.EVE_CONTROL_KEY) throw Error('ambiguous control credential');
    const info = lstatSync(env.EVE_CONTROL_KEY_FILE);
    if (!info.isFile() || info.isSymbolicLink() || info.size < 24 || info.size > 4096)
      throw Error('invalid credential file');
    const key = readFileSync(env.EVE_CONTROL_KEY_FILE, 'utf8').trim();
    if (key.length < 24 || key.length > 4096 || /\s/.test(key)) throw Error('invalid credential');
    return key;
  }
  // Environment credentials are retained only for explicit loopback smoke fixtures.
  if (env.EVE_LOOPBACK_TEST !== '1') throw Error('control credential file required');
  if (!env.EVE_CONTROL_KEY || env.EVE_CONTROL_KEY.length < 24) throw Error('missing credential');
  return env.EVE_CONTROL_KEY;
}

export async function controlCall(origin, key, operation, request, { loopbackTest = false } = {}) {
  const url = new URL(origin);
  if (url.username || url.password || url.search || url.hash || url.pathname !== '/') throw Error('invalid control origin');
  const loopback = ['127.0.0.1', '[::1]'].includes(url.hostname);
  if (url.protocol !== 'https:' && !(loopbackTest && loopback && url.protocol === 'http:')) throw Error('TLS required');
  if (!key || key.length < 24) throw Error('missing control credential');
  const response = await fetch(new URL(operation, url), { method: 'POST', redirect: 'error',
    headers: { authorization: `Bearer ${key}`, 'content-type': 'application/json' },
    body: JSON.stringify(request), signal: AbortSignal.timeout(10000) });
  if (!response.ok) { await response.body?.cancel(); throw Error('EVE control service unavailable'); }
  const chunks = []; let size = 0;
  for await (const chunk of response.body) { size += chunk.length; if (size > 400000) throw Error('oversized lease'); chunks.push(chunk); }
  return JSON.parse(Buffer.concat(chunks).toString());
}
export async function getPulse(origin, key, binding, issuer, options) {
  const challenge = newChallenge(binding);
  const lease = await controlCall(origin, key, 'lease', challenge.request, options);
  return unseal(lease, challenge, issuer);
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    const request = JSON.parse(readFileSync(0, 'utf8'));
    const options = { loopbackTest: process.env.EVE_LOOPBACK_TEST === '1' };
    const key = readControlKey();
    if (process.argv[2] === 'commit') {
      await controlCall(process.env.EVE_CONTROL_URL, key, 'commit', request, options);
    } else if (process.argv[2] === 'lease') {
      const pulse = await getPulse(process.env.EVE_CONTROL_URL, key, request,
        readFileSync(process.env.EVE_ISSUER_PUBLIC_KEY), options);
      const header = Buffer.alloc(8); header.writeBigUInt64LE(BigInt(pulse.expires));
      process.stdout.write(header); process.stdout.write(pulse.delta); pulse.delta.fill(0);
    } else throw Error('invalid operation');
  } catch { process.stderr.write('EVE admission failed; generation must not proceed.\n'); process.exitCode = 1; }
}
