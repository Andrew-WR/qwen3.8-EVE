// Public client crypto. No proprietary policy or vector bank belongs here.
import { generateKeyPairSync, randomBytes, diffieHellman, hkdfSync,
  createCipheriv, createDecipheriv, createPublicKey, sign, verify } from 'node:crypto';

const encodeKey = key => key.export({ type: 'spki', format: 'der' }).toString('base64');
const parseKey = data => createPublicKey({ key: Buffer.from(data, 'base64'), type: 'spki', format: 'der' });
const bytes = obj => Buffer.from(JSON.stringify(obj));
const aad = h => bytes(h);
function aesKey(privateKey, publicKey, header) {
  const shared = diffieHellman({ privateKey, publicKey });
  try { return Buffer.from(hkdfSync('sha256', shared, Buffer.from(header.nonce, 'base64'), 'eve-lease-v1', 32)); }
  finally { shared.fill(0); }
}
export function newChallenge(binding) {
  const pair = generateKeyPairSync('x25519');
  return { privateKey: pair.privateKey, request: { ...binding,
    nonce: randomBytes(32).toString('base64'), recipient: encodeKey(pair.publicKey) } };
}
export function seal(delta, request, signingKey, now = Date.now(), ttl = 30000) {
  if (!Buffer.isBuffer(delta) || delta.length !== request.width * 4) throw Error('invalid delta');
  const pair = generateKeyPairSync('x25519');
  const header = { version: 1, ...request, issued: now, expires: now + ttl,
    sender: encodeKey(pair.publicKey) };
  const key = aesKey(pair.privateKey, parseKey(request.recipient), header);
  try {
    const iv = randomBytes(12);
    const cipher = createCipheriv('aes-256-gcm', key, iv);
    cipher.setAAD(aad(header));
    const ciphertext = Buffer.concat([cipher.update(delta), cipher.final()]);
    const envelope = { header, iv: iv.toString('base64'), ciphertext: ciphertext.toString('base64'),
      tag: cipher.getAuthTag().toString('base64') };
    return { envelope, signature: sign(null, bytes(envelope), signingKey).toString('base64') };
  } finally { key.fill(0); }
}
export function unseal(lease, challenge, issuer, now = Date.now()) {
  if (!lease || !verify(null, bytes(lease.envelope), issuer, Buffer.from(lease.signature, 'base64')))
    throw Error('invalid lease signature');
  const h = lease.envelope.header;
  if (h.version !== 1 || !Number.isSafeInteger(h.issued) || !Number.isSafeInteger(h.expires)
      || h.issued > now + 1000 || h.expires <= now || h.expires - h.issued > 30000)
    throw Error('invalid lease lifetime');
  for (const [k, v] of Object.entries(challenge.request))
    if (h[k] !== v) throw Error('lease binding mismatch');
  const key = aesKey(challenge.privateKey, parseKey(h.sender), h);
  try {
    const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(lease.envelope.iv, 'base64'));
    decipher.setAAD(aad(h));
    decipher.setAuthTag(Buffer.from(lease.envelope.tag, 'base64'));
    const delta = Buffer.concat([decipher.update(Buffer.from(lease.envelope.ciphertext, 'base64')), decipher.final()]);
    if (delta.length !== h.width * 4) { delta.fill(0); throw Error('invalid pulse width'); }
    return { delta, expires: h.expires };
  } finally { key.fill(0); }
}
