import { createHash, verify } from "node:crypto";
import { lstat, readFile, realpath } from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";

const HEX64 = /^[0-9a-f]{64}$/;

export async function verifyRelease(manifestPath, signaturePath, publisherKeyPath) {
  const manifestBytes = await readFile(manifestPath);
  const signatureText = (await readFile(signaturePath, "utf8")).trim();
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(signatureText)) throw new Error("invalid detached signature encoding");
  const signature = Buffer.from(signatureText, "base64");
  const publisherKey = await readFile(publisherKeyPath);
  if (!verify(null, manifestBytes, publisherKey, signature)) throw new Error("release signature verification failed");

  const manifest = JSON.parse(manifestBytes);
  if (manifest.format !== 1 || manifest.status !== "signed-release") throw new Error("manifest is not an installable signed release");
  if (!/^\d+\.\d+\.\d+$/.test(manifest.version ?? "")) throw new Error("invalid release version");
  if (!['tiny-gpu-smoke', 'gpu', 'gpu-offline-beta'].includes(manifest.edition)) throw new Error("invalid release edition");
  if (!HEX64.test(manifest.image_digest ?? "")) throw new Error("invalid image digest");
  if (!HEX64.test(manifest.issuer_public_key_sha256 ?? "")) {
    throw new Error("invalid issuer public key digest");
  }
  if (typeof manifest.image !== "string" || !manifest.image.endsWith(`@sha256:${manifest.image_digest}`)) {
    throw new Error("image reference is not pinned to manifest digest");
  }
  if (!manifest.files || Array.isArray(manifest.files) || typeof manifest.files !== "object") {
    throw new Error("manifest files must be an object");
  }
  const artifactNames = ["compose", "installer", "product_installer", "release_verifier",
    "plugin", "lease_client", "lease_crypto"];
  if (!manifest.artifacts || artifactNames.some(name =>
    typeof manifest.artifacts[name] !== "string" || !(manifest.artifacts[name] in manifest.files))) {
    throw new Error("manifest does not bind every required product artifact");
  }
  const packageRoot = path.dirname(await realpath(manifestPath));
  for (const [relative, digest] of Object.entries(manifest.files)) {
    if (!HEX64.test(digest) || path.isAbsolute(relative) || relative.includes("..") || relative.includes("\\")) {
      throw new Error(`unsafe manifest file entry: ${relative}`);
    }
    const candidate = path.resolve(packageRoot, relative);
    if (!candidate.startsWith(`${packageRoot}${path.sep}`)) throw new Error(`file escapes package: ${relative}`);
    const info = await lstat(candidate);
    if (!info.isFile() || info.isSymbolicLink()) throw new Error(`release file is not a regular file: ${relative}`);
    const actual = createHash("sha256").update(await readFile(candidate)).digest("hex");
    if (actual !== digest) throw new Error(`release file digest mismatch: ${relative}`);
  }
  return manifest;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    const [, , manifest, signature, publisherKey] = process.argv;
    if (!manifest || !signature || !publisherKey) throw new Error("usage: release_verify.mjs MANIFEST SIGNATURE PUBLISHER_KEY");
    process.stdout.write(`${JSON.stringify(await verifyRelease(manifest, signature, publisherKey))}\n`);
  } catch (error) {
    process.stderr.write(`${error.message}\n`);
    process.exitCode = 2;
  }
}
